package com.example.voting_dapp

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
